﻿
Partial Class Categories
    Inherits System.Web.UI.Page

End Class
