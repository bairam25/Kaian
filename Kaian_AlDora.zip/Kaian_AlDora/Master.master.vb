﻿
Partial Class Master
    Inherits System.Web.UI.MasterPage

End Class

