﻿
Partial Class Brands
    Inherits System.Web.UI.Page

End Class
