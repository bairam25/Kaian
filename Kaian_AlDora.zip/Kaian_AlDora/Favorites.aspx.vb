﻿
Partial Class Favorites
    Inherits System.Web.UI.Page

End Class
