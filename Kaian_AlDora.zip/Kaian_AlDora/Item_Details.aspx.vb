﻿
Partial Class Item_Details
    Inherits System.Web.UI.Page

End Class
